---
name: Bug report
about: Please tell us more about the error
title: ''
labels: ''
assignees: ''

---

**Describe the bug**
A clear and concise description of what the bug is.

**Erroneous code**
Please use markdown to send the code here.


**Additional infos**
 - OS:
 - python --version:
 - norminette -v:

**Additional context**
Add any other context about the problem here.
