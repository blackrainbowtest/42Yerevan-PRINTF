void foo()
{
float a = 4.2;
a = 4.2e4;
a = 4.2e-4;
a = 10.12e3f;
a = 4.2f;
a = .2f;
a = 10.f;
a = 10.e12f;
a = .4;
a = .4e3-1;
a = 0.-+12;
}
