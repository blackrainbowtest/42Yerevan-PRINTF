struct foo {
	struct bar {
		int x;
	} baz;
};

void frob() {
	struct bar b;
}
