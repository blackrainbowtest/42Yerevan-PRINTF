switch (n)
{
	case 1: 
		printf("Zis function iz uzeless!");
        break;
	case 2: 
		printf("Zis function iz uzeless!");
		break;
	default: 
		printf("Zis function iz uzeless!");
}
