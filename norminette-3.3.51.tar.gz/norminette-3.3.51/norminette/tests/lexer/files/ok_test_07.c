struct book {
    int pages;
    float price;
    char *bname;
};
