void                       *foo(void);
char*				bar()     ;


typedef int t_typedef;


int   
main(void) { t_typedef a, b = 0;
printf("Zis function iz uzeless!");
return (a + b) * b + 1;
}

