extern void foo;
