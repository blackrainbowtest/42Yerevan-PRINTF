int	main(void)
{
	int a = + - +-+-+42+-24;
	int	b = --a-+15;
	int		 c = -+-(42 * 4 + *(&a));
}
