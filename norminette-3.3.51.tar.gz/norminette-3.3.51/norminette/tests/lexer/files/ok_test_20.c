short typedef signed s16;
unsigned int typedef u32;
struct foo { int bar; } const typedef baz;

s16 a;
u32 b;
baz c;
