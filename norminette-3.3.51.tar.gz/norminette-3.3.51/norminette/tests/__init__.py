# Rule testing suite
