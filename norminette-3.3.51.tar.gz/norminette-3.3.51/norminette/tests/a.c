int	(foo(int a))
{
	if (1)
		{
					
}
	return (1);
}

short int a() { return 1; }

int (faa)(int *a(int), char b, int c, int r)
{
	return 1;
}

#include <stdlib.h>
int	*truc()
{
	return malloc(sizeof(int));
}

int (*f2(void))(int) {
	return foo; }

int	((*((((bar)(int a))))))(int)
{
	return (foo);
}

int	(*(f)(char a, int t, int b))(int) { return foo;}

int	(*fp(int)); //Function pointer, NOT FUNC!
int	((*(fp2))(int a));

//int ((*T)(int))(int);

int ((*f23(int))) ;
int (*fff[1])(void);
enum Bla {
	A,
	B
};

enum Bla	func(void);
unsigned enum Bla	func(void);
long long enum Bla	func(void);
enum long long Bla	func(void);
enum long long Bla	func(void);
 Bla	func(void);
youpi	func2(void);
trololo43 const	func3(youpibanane cahuete);
trololo43	func3(youpibanane);
trololo43	func3(cahuete);
trololo43	func3(youpibanane	cahuete);
trololo43	func3(youpibanane cahuete, lol choupette);
trololo43	func3(youpibanane cahuete, lol  choupette);
trololo43	func3(youpibanane cahuete,lol choupette);
trololo43	func3(youpibanane cahuete, lol ***choupette);
trololo43	func3(youpibanane cahuete, lol * choupette);
trololo43	func3(youpibanane **cahuete, lol*** **choupette);
trololo	trololol	func4(uopi sks);
***func4(udidf fdfd);
