result = result * 10 + *(*str)++ - '0';
func(i * a, *b, (&c));

int	main(void *toto)
{
	return ;
}
