int	main(void)
{
	if (!((*array)[i] = test((test + 1))))
		return (NULL);
}
