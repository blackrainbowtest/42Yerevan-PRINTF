#define TOTO "TATA"
#define PRINTF       "printf"
#define TOTO 12
