#define LENGTH 8
typedef char	t_word[8];
typedef char	t_word[LENGTH];

typedef void	(*t_func_definiton)(toto arg);