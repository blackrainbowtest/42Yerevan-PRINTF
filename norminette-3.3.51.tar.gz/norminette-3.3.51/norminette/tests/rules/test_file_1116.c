t_queue	*dequeue(t_queue **head)
{
	t_queue	*first;

	tvp = &tv;
	first = *head;
}
