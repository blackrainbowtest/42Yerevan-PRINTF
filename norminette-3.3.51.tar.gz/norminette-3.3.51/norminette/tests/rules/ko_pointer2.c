int	main(void) {
	int	***	*	a;
	int			b;	a &= ***b;
}

int	main(void) {
	int	***	*	a;
	int			b;	if 					(5 * 		 ***a)
	{
		b = 		 	12;
		b
			&& b;
	}
}

int	main(void) {
	int	***	*	a;
	int			b;	if 					(5 * 		 ***a)
	{
		b = 		 	12;
		b
			***b;
	}
}

int	main(void) {
	int	***	*	a;
	int			b;	if 					(5 * 		 ***a) {
		b = 		 	12;
	}
}

int	main(void) {
	int	***	*	a;
	int			b;	if 					(5 * 		 ***	a)
		b = 		 	12;
}
