int	main(void)
{
	return (void *) 0;
	return (int) var_name;
	return (var1) + var2;
	return (void *)(var_name);
	return (int) var1 + 2;
	return ((void *) 0);
	return ((int) var_name);
	return ((var1) + var2);
	return ((void *)(var_name));
	return ((int) var1 + 2);
}
