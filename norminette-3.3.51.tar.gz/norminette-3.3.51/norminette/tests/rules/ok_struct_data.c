int	main(void)
{
	int		i;

	i = i.c;
	v = v->v;
	while (v->c)
		if (c.v != 0)
			i->c->i += 1;
	i->c = i->c * i->(*d);
}
