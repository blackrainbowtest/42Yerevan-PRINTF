t_montype	g_globale;
t_montype	g_glob;