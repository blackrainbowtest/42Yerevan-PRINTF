int	((*g_conv[13])(t_syntax syntax, t_buffer *buffer, va_list va));

void	main(void)
{
	2 +*y;
}

void	main(void)
{
	2 + *y;
}
