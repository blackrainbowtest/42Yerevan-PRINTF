#define STUFF 1
#ifndef FOO
# define FOO
# ifndef BAR
#  define BAR
# endif
#endif
