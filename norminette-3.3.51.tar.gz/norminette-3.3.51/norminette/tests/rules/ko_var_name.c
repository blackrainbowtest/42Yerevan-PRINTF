int notValid;
int NotValidEither;
