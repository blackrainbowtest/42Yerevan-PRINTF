void	*main(void *i);
int	(*fpfunc)(int x, int y);
result = (*fpcomparer)(a, a * *b);