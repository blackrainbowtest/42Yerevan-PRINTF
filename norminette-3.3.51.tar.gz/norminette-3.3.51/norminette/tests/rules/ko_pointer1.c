int	main(void) {
	int	*** *a;
}

int	main(void) {
	int	***	*	a;
	int			b;	a = b * (*(*(*(*a) ) ) );
}

int	main(void) {
	int	***	*	a;
	int			b;	b &= **(++**a);
}

int	main(void) {
	int	***	*	a;
	int			b;	b &= ****a++;
}

int	main(void) {
	int	***	*	a;
	int			b;	b &= --****a;
}