const char	*(*func)(void);

int	render_map(void *param)
{
	g->spritedist[i] = ((g->posx - sprite.x) * (g->posx - sprite.x) + 1);
}
