int	func(void);

int	func2(void)
{
	return (1);
}

typedef struct s_sTRuct	t_Struct;
struct					s_sTRuct;

int						g_glOb;

int	Main(void)
{
	char		*sTr;
	int			TAB;
	size_T		val;
	t_Struct	val;

	return ;
}
