int	main(void)
{
	a *= a;
	while (i, 2)
	{
		break ;
	}
	return (*toto, "abvc,edwd");
	return (2 + *tptp);
}
