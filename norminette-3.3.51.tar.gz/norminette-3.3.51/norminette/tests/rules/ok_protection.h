#ifndef OK_PROTECTION_H
# define OK_PROTECTION_H
# define TOTO "tata"

void	main(void);
int	g_toto;

v = 0;
#endif
