int	g_a; int	g_b;

void	f(void)
{
	write(1, "a", 1); write(1, "a", 1);
}
