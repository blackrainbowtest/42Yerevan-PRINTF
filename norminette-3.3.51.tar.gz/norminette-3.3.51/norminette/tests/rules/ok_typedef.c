typedef struct s_struct
{
	int	a;
	int	b;
}	t_struct;

typedef struct s_struct	t_struct;

struct s_type
{
	int	a;
};

int	main(void)
{
	struct s_type	toto;
}
