int	main(void)
{
	if (((unsigned char*)s1)[curr] != ((unsigned char*)s2)[curr])
		return (((unsigned char*)s1)[curr] - ((unsigned char*)s2)[curr]);
}

struct my_struct			g_struct = {
	.field = (void *)&value
};

int	main(void)
{
	t_quaternion	g_quat = {
		.r = 1,
		.i = 0,
		.j = 0,
		.k = 0
	};
}
t_quaternion				g_quat = {
	.r = 1,
	.i = 0,
	.j = 0,
	.k = 0
};
*result = (t_quaternion)
{
	.r = 1,
	.i = 0,
	.j = 0,
	.k = 0
};

static const t_quaternion	g_quat = {.r = 1, .i = 0, .j = 0, .k = 0};
static const t_quaternion	g_quat = {r : 1, i : 0, j: 0, k : 0 };
static const t_quaternion	g_quats[4] = {[0].r = 3, [1].i = 5 };
*result = (t_quaternion){1, 0, 0, 0};
*result = (t_quaternion){r : 1, i : 0, j : 0, k : 0 };