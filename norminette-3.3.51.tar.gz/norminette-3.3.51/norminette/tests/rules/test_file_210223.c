int	main(void)
{
	if (pthread_create(&philos[i].philo_status_thread, NULL, \
		check_status, &philos[i]))
		return (-1);
	printf("\nOh noes. I, n°%i, no longer thinks, and therefore, is no more.\
	*dies in philosopher*\n", this->uid);
}

int	main(void)
{
	if ((-(cy->height * 0.5)) < z[0] && z[0] < ((cy->height * 0.5)))
		return ;
}
