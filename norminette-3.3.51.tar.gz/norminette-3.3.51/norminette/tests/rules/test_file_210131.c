const int	*get_draw_info(t_draw *draw, double perpwalldist,
				t_texture texture[4], t_mov mov);

int	main(void)
{
	fct(aaa, a,
		b);
}
