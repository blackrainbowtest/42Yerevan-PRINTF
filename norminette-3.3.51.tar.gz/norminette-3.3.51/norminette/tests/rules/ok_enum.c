typedef enum e_toto
{
	TOTO = 0,
	TUTU,
	TITI,
}	t_toto;
