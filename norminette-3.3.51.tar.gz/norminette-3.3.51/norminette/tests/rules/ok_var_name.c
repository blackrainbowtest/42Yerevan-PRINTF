int	main(void)
{
	int	a;
	int	b;
	int	c_d_e;
	int	c_d_e2;
	int	f4;
}

int	main(void)
{
	int	a;
	int	b;
	int	c_d_e;
	int	c_d_e2;
	int	f4;
}

int	main(void)
{
	int	a;
	int	b;
	int	c_d_e;
	int	c_d_e2;
	int	f4;
}

int	main(void)
{
	int	a;
	int	b;
	int	c_d_e;
	int	c_d_e2;
	int	f4;
}

int	main(void)
{
	int	a;
	int	b;
	int	c_d_e;
	int	c_d_e2;
	int	f4;
}
