#include <main.c>
#define KO_INcLUDE_C
#include <main.c>
