int	main(void)
{
	int	a;

	// issue 13, 16, 17
	a = 1;
	return (~a);
}

int	main(void)
{
	const int	len;

	len = ft_len(n);
	a = 1;
}

typedef char	t_my_type;

int	main(int argc, char **argv)
{
	size_t	size;

	return (0);
}
