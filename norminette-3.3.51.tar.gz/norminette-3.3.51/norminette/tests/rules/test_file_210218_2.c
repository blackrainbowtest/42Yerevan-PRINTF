#ifndef FT_EXAMPLE_H
# define FT_EXAMPLE_H

void	ft_foobar(
			char really_long_variable_name_for_the_purposes_of_this_example,
			char the_second_one_wouldent_fit_on_the_same_line
			);

#endif