typedef struct s_toto
{
	int	a;
}		t_toto;
struct s_tata
{
	int	a;
	int	b;
};

union u_val			g_var;
struct s_toto		g_var;

int	main(void)
{
	struct s_type				val;
	int							a;
}
