int	main(void)
{
	nbr = (int)ft_ternary(sign, n, va);
	size = ft_size(nb, val);
}
