int	g_toto = 0;

	// toototo
	/*
	 ** aallo
	 **
	 */

int	main(void)
{
	int			b;
	static int	i = 0;

	while (i < 0)
	{
		return (val);
	}
	arr = (char **)malloc(sizeof(char *)
			* (ft_lstsize(lst) + 1));
	a = b + c;
	else if (toto
		&& tata || (yoyo
			|| tutu)
		&& tata)
		if (che)
			return (void);
}

int	toto2(void)
{
	else if (toto && tata || toutou
		|| toto)
	{
		a = a
			+ (
				(
					(
						a
						+ b
						)
					)
				+ c
				);
		return ;
	}
	else if (woa)
	{
		print ((a + 'wolabrute') + b);
	}
}
