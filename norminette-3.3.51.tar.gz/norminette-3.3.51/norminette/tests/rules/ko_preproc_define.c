#define toto f(x)
#define A AB+AB
#define PRINTF printf()
#define PRINTF printf
#define TOTO TATA 12
 #define TOTo TATa