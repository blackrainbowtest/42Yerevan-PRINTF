
void	ft_calculation_size_nbr(int *size_nbr, char *nbr, t_all *all)
{
	(void)(*size_nbr)--;
}