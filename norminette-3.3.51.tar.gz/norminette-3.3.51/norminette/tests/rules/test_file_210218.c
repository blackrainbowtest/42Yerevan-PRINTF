int	main(void)
{
	x = ((int)x) * x;
}
