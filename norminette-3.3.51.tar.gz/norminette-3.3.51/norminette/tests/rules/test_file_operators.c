int	main(void)
{
	int				a;
	unsigned int	b[1];

	a = -10;
	*b = (unsigned int)-a;
	return (0);
}
