int	a(int a)
{
	return (a);
}

int	main(void)
{
	return a(0);
}

struct s_a
{
	char	jklsfdsk;
	union
	{
		int		a;
		char	b;
	};
};

int	main(void)
{
	return (0);
}

int	main(int argc, char **argv)
{
	int	BLEH;
	int	vla[2 + BLEH + 2];

	(void) argv;
	return (0);
}

(void/* fkdslkdjfdsjl */) argc;

int	main(void)
{
	int	a;

	(void/* fkdslkdjfdsjl */) argc;
	(void/* fkdslkdjfdsjl */) argv;
	return (0);
}

int	main(void)
{
	int	a;

	goto a;
	printf("meh");
	a : printf(":ah:");
	return (0);
}

int	main(int argc, char **argv)
{
	const char	*a;

	(void) argc;
	(void) argv;
	a = "kfldfksjldfkjskl"/* random comment */"jlsfkdfjdsldf";
	return (0);
}

int	main(int argc, char **argv)
{
	(void) argc;
	(void) argv;
	return (0/* Hello world! */);
}

int	main(void)	
{
	return (0);
}

int	main(void)	
{	
	return (0);
}	
