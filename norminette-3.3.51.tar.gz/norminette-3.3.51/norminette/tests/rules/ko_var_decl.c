void	tata(const char xc);
void	tata(const t_struct *a);
void	tata(const char w);

int	main(int toto, int c, int v)
{
	if (i --)
		while (1)
		{
			return ;
		}
	else
		return ;
}

void	toto(void)
{
	return ;
}
