#define TTOO 1

int	g_toto = 0;

int	main(void)
{
	int					tab[1];
	void				l;
	int					i;
	static t_struct		t = 0;

	if (i++)
	{
		return ;
	}
}
