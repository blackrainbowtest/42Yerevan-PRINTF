# define STUFF 1
#ifndef FOO
#define FOO 2
# endif
#   define BAR 3
