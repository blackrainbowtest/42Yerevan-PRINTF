int	BAD_funcname1(void);
int	bad_funcName2(void);
int	B(void);
