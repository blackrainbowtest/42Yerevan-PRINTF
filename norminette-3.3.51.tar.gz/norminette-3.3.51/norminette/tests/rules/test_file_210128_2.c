void	read_config(t_list **lights, t_gui gui){}
