enum e_random_enum
{
	first_enum = 0,
	second_enum,
	third_enum,
	fourth_enum = 42
};