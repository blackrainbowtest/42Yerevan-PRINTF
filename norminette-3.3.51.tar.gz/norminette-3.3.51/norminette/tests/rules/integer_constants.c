int	main(void)
{
	int					dec_int = 28;
	unsigned int		dec_uint = 4000000024u;
	long				dec_long = 2000000022l;
	unsigned long		dec_ulong = 4000000000ul;
	long long			dec_llong = 9000000000LL;
	unsigned long long	dec_ullong = 900000000001ull;
	__int64				dec_i64 = 9000000000002I64;
	unsigned __int64	dec_ui64 = 90000000000004ui64;
	int					oct_int = 024;
	unsigned int		oct_uint = 04000000024u;
	long				oct_long = 02000000022l;
	unsigned long		oct_ulong = 04000000000UL;
	long long			oct_llong = 044000000000000ll;
	unsigned long long	oct_ullong = 044400000000000001Ull;
	__int64				oct_i64 = 04444000000000000002i64;
	unsigned __int64	oct_ui64 = 04444000000000000004uI64;
	int					hex_int = 0x2a;
	unsigned int		hex_uint = 0XA0000024u;
	long				hex_long = 0x20000022l;
	unsigned long		hex_ulong = 0XA0000021uL;
	long long			hex_llong = 0x8a000000000000ll;
	unsigned long long	hex_ullong = 0x8A40000000000010uLL;
	__int64				hex_i64 = 0x4a44000000000020I64;
	unsigned __int64	hex_ui64 = 0x8a44000000000040Ui64;
}

int	main(long long i, long long int j, long int k, short short l, short short int m, short int n, long o, short p)
{
	long long		i;
	long long int	j;
	long int		k;
	short short		l;
	short short int	m;
	short int		n;
	long			o;
	short			p;
}

