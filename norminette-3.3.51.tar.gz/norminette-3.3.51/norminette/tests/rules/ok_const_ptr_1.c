int	func(void)
{
	int const							*var = 0;
	const int							*var = 0;
	t_obj const							*var = 0;
	int *const *const *const *const		var = 0;
	int **const							var = 0;
	int const *const **const			var = 0;
	const t_obj							*var = 0;
	t_obj *const *const *const *const	var = 0;
	t_obj **const						var = 0;
	t_obj const *const **const			var = 0;
}
