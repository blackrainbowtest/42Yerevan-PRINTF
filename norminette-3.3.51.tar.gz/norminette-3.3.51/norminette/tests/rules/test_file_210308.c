void	test1(void)
{
}
/**
 * test
 */

void	test2(void)
{
}

/**
 * test
 */

void	test2(void)
{
}

/**
 * test
 */
void	test2(void)
{
}
/**
 * test
 */
void	test2(void)
{
}
#define TOTO 2
void	test2(void)
{
}
