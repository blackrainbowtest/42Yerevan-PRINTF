void ft_hexdump(char **files, int argc, int i){
	while (i < argc)
	{
		if (argc > 2)
			{if ((fd = open(files[i], O_RDONLY)) == -1)
			return ;}
	}
}

