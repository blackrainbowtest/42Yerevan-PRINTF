int	main(void) {
	int	***	*	a;
	int			b;	if 					(5 * 		 *** a)
		b = 		 	12;
}

int	main(void) {
	int	***	*	a;
	int			b;	if 					(5 * 		 ***a)
		b = 		 	12;
}

int	main(void) {
	int	***	*	a;
	int			b;	a = b * (*(*(*(*a) ) ) );
	(*a 	 					) = b * 				a;
}

int	main(void) {
	int	toto tata
	*	 * * *	a;
	int			b;
}