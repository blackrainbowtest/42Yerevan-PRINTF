int	main(void)
{
	while (1)
		return ;
	break ;
}
