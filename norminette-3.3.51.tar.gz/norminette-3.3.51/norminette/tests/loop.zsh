for ((i = 0; i < 100; i++)); do 
python . **/*.c; done
