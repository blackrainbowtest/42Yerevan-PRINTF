__version__ = "3.3.51"
__name__ = "norminette"
__author__ = "42"
__author__email__ = "pedago@42.fr"
